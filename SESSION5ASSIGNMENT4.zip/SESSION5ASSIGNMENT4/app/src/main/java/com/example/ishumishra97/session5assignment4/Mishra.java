package com.example.ishumishra97.session5assignment4;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

/**
 * Created by ishu.mishra97 on 6/24/2016.
 */
public class Mishra extends Activity {
    TextView tv;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.peak);
        tv=(TextView)findViewById(R.id.textView4);
        Bundle bundle = getIntent().getExtras();
//Extract the data…
        String username = bundle.getString("ISHU");

//Create the text view
        tv.setText("WELCOME" + bundle);
    }
}
